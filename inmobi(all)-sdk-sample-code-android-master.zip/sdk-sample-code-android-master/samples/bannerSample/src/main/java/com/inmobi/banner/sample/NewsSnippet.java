package com.inmobi.banner.sample;

public final class NewsSnippet {
    String title;
    String imageUrl;
    String content;
    String landingUrl;
    boolean isSponsored;
}