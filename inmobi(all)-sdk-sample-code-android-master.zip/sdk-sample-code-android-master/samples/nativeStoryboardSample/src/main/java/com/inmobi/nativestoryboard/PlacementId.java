package com.inmobi.nativestoryboard;

/**
 * Created by davendar.ojha on 9/15/16.
 */
public interface PlacementId {
   long YOUR_PLACEMENT_ID_HERE = 1455967345507L;
}