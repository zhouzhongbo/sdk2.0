package com.inmobi.nativead.sample.photopages;

public final class PageItem {
    String imageUrl;
}