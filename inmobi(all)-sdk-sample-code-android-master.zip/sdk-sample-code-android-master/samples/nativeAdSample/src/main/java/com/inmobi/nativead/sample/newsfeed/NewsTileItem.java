package com.inmobi.nativead.sample.newsfeed;

public final class NewsTileItem {
    String imageUrl;
    String title;
    String content;
    String landingUrl;
}