package com.inmobi.nativead.sample.photofeed;

public final class PhotosFeedItem {
    public String title;
    public String imageUrl;
    public String landingUrl;
}