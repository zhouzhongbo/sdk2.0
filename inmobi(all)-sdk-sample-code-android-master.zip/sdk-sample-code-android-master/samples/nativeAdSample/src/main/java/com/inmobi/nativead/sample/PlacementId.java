package com.inmobi.nativead.sample;

public interface PlacementId {
    long YOUR_PLACEMENT_ID = 1474325589886L;
}
