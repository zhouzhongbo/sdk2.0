package com.inmobi.nativead.sample.newsheadline;

public final class NewsSnippet {
    String title;
    String imageUrl;
    String content;
    String landingUrl;
}