package com.mopub.mobileads;

import android.content.Context;

/**
 * @deprecated As of release 2.4
 */
@Deprecated
public class FacebookKeywordProvider {
    /**
     * @deprecated As of release 2.4
     */
    @Deprecated
    public static String getKeyword(Context context) {
        return null;
    }
}
