package com.inmobi.samples.nativestoryboards;

import android.content.Context;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.AttributeSet;
import android.view.MotionEvent;

import com.inmobi.samples.R;
import com.inmobi.sdk.InMobiSdk;

public class NativeStoryBoardsActivity extends AppCompatActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Native Storyboard only works in portrait orientation.
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT);

        //Initialize Inmobi SDK before any API call.
        InMobiSdk.init(this, "12345678901234567890123456789012");
        InMobiSdk.setLogLevel(InMobiSdk.LogLevel.DEBUG);

        setContentView(R.layout.activity_native_storyboards);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        TabLayout tabLayout = (TabLayout) findViewById(R.id.tab_layout);
        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);

        final ViewPager viewPager = (ViewPager) findViewById(R.id.pager);
        final PagerAdapter adapter = new PagerAdapter(getSupportFragmentManager(), tabLayout);
        viewPager.setAdapter(adapter);
        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }

    private static class PagerAdapter extends FragmentStatePagerAdapter {

        private static final int NUM_TABS = 4;

        private static final int POSITION_AD_PLACER = 0;

        private static final int POSITION_CUSTOM_INTEGRATION = 1;

        private static final int POSITION_LIST_VIEW_INTEGRATION = 2;

        private static final int POSITION_RECYCLER_VIEW_INTEGRATION = 3;

        public PagerAdapter(FragmentManager fm, TabLayout tabLayout) {
            super(fm);
            for (int position = 0; position < NUM_TABS; position++) {
                tabLayout.addTab(tabLayout.newTab().setText(getTitle(position)));
            }
        }

        @Override
        public Fragment getItem(int position) {
            switch (position) {
                case POSITION_AD_PLACER:
                    return new NewsFeedFragment();

                case POSITION_CUSTOM_INTEGRATION:
                    return new CustomIntegrationFragment();

                case POSITION_LIST_VIEW_INTEGRATION:
                    return new CustomIntegrationFeedFragment();

                case POSITION_RECYCLER_VIEW_INTEGRATION:
                    return new CustomIntegrationRecyclerFeedFragment();

                default:
                    throw new IllegalArgumentException("No fragment for position:" + position);
            }
        }

        String getTitle(int position) {
            switch (position) {
                case POSITION_AD_PLACER:
                    return NewsFeedFragment.getTitle();

                case POSITION_CUSTOM_INTEGRATION:
                    return CustomIntegrationFragment.getTitle();

                case POSITION_LIST_VIEW_INTEGRATION:
                    return CustomIntegrationFeedFragment.getTitle();

                case POSITION_RECYCLER_VIEW_INTEGRATION:
                    return CustomIntegrationRecyclerFeedFragment.getTitle();

                default:
                    throw new IllegalArgumentException("No Title for position:" + position);
            }
        }

        @Override
        public int getCount() {
            return NUM_TABS;
        }
    }

    //This prevents accidental page switch from last card in the Storyboards.
    public static class NonSwipeableViewPager extends ViewPager {

        public NonSwipeableViewPager(Context context) {
            super(context);
        }

        public NonSwipeableViewPager(Context context, AttributeSet attrs) {
            super(context, attrs);
        }

        @Override
        public boolean onInterceptTouchEvent(MotionEvent event) {
            // Never allow swiping to switch between pages
            return false;
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            // Never allow swiping to switch between pages
            return false;
        }
    }
}