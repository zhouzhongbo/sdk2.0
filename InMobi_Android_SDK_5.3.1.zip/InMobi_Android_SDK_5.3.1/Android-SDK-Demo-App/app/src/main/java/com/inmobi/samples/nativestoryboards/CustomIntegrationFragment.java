package com.inmobi.samples.nativestoryboards;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.widget.SwipeRefreshLayout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.inmobi.ads.InMobiAdRequestStatus;
import com.inmobi.ads.InMobiNativeStrand;
import com.inmobi.samples.R;

/**
 * Demonstrates the use of InMobiNativeStrand to place a single ad.
 * <p/>
 * Note: Swipe to refresh ads.
 */
public class CustomIntegrationFragment extends android.support.v4.app.Fragment
        implements InMobiNativeStrand.NativeStrandAdListener {

    private static final String TAG = CustomIntegrationFragment.class.getSimpleName();

    private ViewGroup mContainer;

    private View mAdView;

    private InMobiNativeStrand mInMobiNativeStrand;

    private static final long YOUR_PLACEMENT_ID_HERE = PLACEMENT_ID;

    public static String getTitle() {
        return "Custom Placement";
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_custom_integration, container, false);
        mContainer = (ViewGroup) view.findViewById(R.id.container);

        final SwipeRefreshLayout swipeRefreshLayout = SwipeRefreshLayoutWrapper.getInstance(getActivity(),
                new SwipeRefreshLayoutWrapper.Listener() {
                    @Override
                    public boolean canChildScrollUp() {
                        return false;
                    }

                    @Override
                    public void onRefresh() {
                        reloadAd();
                    }
                });
        swipeRefreshLayout.addView(mContainer);
        return swipeRefreshLayout;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mInMobiNativeStrand = new InMobiNativeStrand(getActivity(), YOUR_PLACEMENT_ID_HERE, this);
        Log.d(TAG, "Requesting ad");
        loadAd();
    }

    @Override
    public void onAdLoadSucceeded(@NonNull InMobiNativeStrand nativeStrand) {
        clearAd();
        //Pass the old ad view as the first parameter to facilitate view reuse.
        mAdView = mInMobiNativeStrand.getStrandView(mAdView, mContainer);
        if (mAdView == null) {
            Log.e(TAG, "Could not render Strand!");
        } else {
            mContainer.addView(mAdView);
        }
    }

    @Override
    public void onAdLoadFailed(@NonNull InMobiNativeStrand nativeStrand,
                               @NonNull final InMobiAdRequestStatus inMobiAdRequestStatus) {
        Log.w(TAG, "Ad Load failed (" + inMobiAdRequestStatus.getMessage() + ")");
    }

    @Override
    public void onAdImpressed(@NonNull InMobiNativeStrand inMobiNativeStrand) {
        Log.i(TAG, "Impression recorded successfully");
    }

    @Override
    public void onAdClicked(@NonNull InMobiNativeStrand inMobiNativeStrand) {
        Log.i(TAG, "Ad clicked");
    }

    @Override
    public void onDestroyView() {
        mInMobiNativeStrand.destroy();
        super.onDetach();
    }

    private void loadAd() {
        mInMobiNativeStrand.load();
    }

    private void clearAd() {
        mContainer.removeAllViews();
    }

    private void reloadAd() {
        clearAd();
        loadAd();
    }
}
