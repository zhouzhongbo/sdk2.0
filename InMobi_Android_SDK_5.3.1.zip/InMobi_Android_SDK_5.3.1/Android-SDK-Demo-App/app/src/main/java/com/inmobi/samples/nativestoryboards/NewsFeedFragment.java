package com.inmobi.samples.nativestoryboards;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.ListFragment;
import android.support.v4.view.ViewCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.inmobi.ads.InMobiStrandAdapter;
import com.inmobi.ads.InMobiStrandPositioning;
import com.inmobi.samples.R;
import com.inmobi.samples.nativestoryboards.FeedData.FeedItem;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Demonstrates integration via {@link InMobiStrandAdapter}.
 */
public final class NewsFeedFragment extends ListFragment {

    private static final String TAG = NewsFeedFragment.class.getSimpleName();

    private InMobiStrandAdapter mStrandAdapter;

    private ArrayList<FeedData.FeedItem> mFeedItems;

    private static final long YOUR_PLACEMENT_ID_HERE = PLACEMENT_ID;

    private final InMobiStrandAdapter.NativeStrandAdListener mAdListener = new InMobiStrandAdapter.NativeStrandAdListener() {
        @Override
        public void onAdLoadSucceeded(int i) {
            Log.d(TAG, "Strand loaded at position " + i);
        }

        @Override
        public void onAdRemoved(int i) {
            Log.d(TAG, "Strand removed at position: " + i);
        }
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View listFragmentView = super.onCreateView(inflater, container, savedInstanceState);
        final SwipeRefreshLayout swipeRefreshLayout = SwipeRefreshLayoutWrapper.getInstance(getActivity(),
                new SwipeRefreshLayoutWrapper.Listener() {
                    @Override
                    public boolean canChildScrollUp() {
                        final ListView listView = getListView();
                        return listView.getVisibility() == View.VISIBLE && canListViewScrollUp(listView);
                    }

                    @Override
                    public void onRefresh() {
                        refreshAds();
                    }
                });
        swipeRefreshLayout.addView(listFragmentView,
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        return swipeRefreshLayout;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mFeedItems = FeedData.generateFeedItems(50);
        //Load the ads after activity has been created.
        prepareToLoadAds();
    }

    public void prepareToLoadAds() {
        final BaseAdapter originalAdapter = new FeedItemAdapter(getActivity(), mFeedItems);
        final InMobiStrandPositioning.InMobiClientPositioning clientPositioning =
                new InMobiStrandPositioning.InMobiClientPositioning();
        clientPositioning.addFixedPosition(2)
                .addFixedPosition(4)
                .addFixedPosition(8)
                .enableRepeatingPositions(5);

        if (mStrandAdapter != null) {
            mStrandAdapter.destroy();
        }
        mStrandAdapter = new InMobiStrandAdapter(getActivity(),
                YOUR_PLACEMENT_ID_HERE, originalAdapter, clientPositioning);
        mStrandAdapter.setListener(mAdListener);
        originalAdapter.notifyDataSetChanged();
        mStrandAdapter.load();
        setListAdapter(mStrandAdapter);
    }

    public static String getTitle() {
        return "Ad Placer";
    }

    @Override
    public void onDestroyView() {
        if (mStrandAdapter != null) {
            mStrandAdapter.destroy();
        }
        super.onDestroy();
    }

    private void refreshAds() {
        if (null == mStrandAdapter || null == getListView()) {
            Log.e(TAG, "The list-view or the adapter cannot be null!");
        } else {
            mStrandAdapter.refreshAds(getListView());
        }
    }

    public class FeedItemAdapter extends ArrayAdapter<FeedItem> {
        private ArrayList<FeedItem> users;
        private LayoutInflater layoutInflater;

        class ContentViewHolder {
            TextView title;
            TextView subtitle;
            TextView time_tt;
            TextView description_tt;
            ImageView thumb_image;
            ImageView big_image;
            ImageView bottom_img;
        }

        public FeedItemAdapter(Context context, ArrayList<FeedData.FeedItem> users) {
            super(context, R.layout.listitem, R.id.title, users);
            this.users = users;
            this.layoutInflater = LayoutInflater.from(context);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View rowView = convertView;
            if (null == rowView) {
                rowView = layoutInflater.inflate(R.layout.listitem, parent, false);
                ContentViewHolder viewHolder = new ContentViewHolder();
                viewHolder.title = (TextView) rowView.findViewById(R.id.title);
                viewHolder.subtitle = (TextView) rowView.findViewById(R.id.subtitle);
                viewHolder.time_tt = (TextView) rowView.findViewById(R.id.time_tt);
                viewHolder.description_tt = (TextView) rowView.findViewById(R.id.description_tt);
                viewHolder.thumb_image = (ImageView) rowView.findViewById(R.id.thumb_image);
                viewHolder.big_image = (ImageView) rowView.findViewById(R.id.big_image);
                viewHolder.bottom_img = (ImageView) rowView.findViewById(R.id.bottom_img);

                rowView.setTag(viewHolder);
            }

            FeedItem user = users.get(position);
            ContentViewHolder holder = (ContentViewHolder) rowView.getTag();
            holder.title.setText(user.getTitle());
            holder.subtitle.setText(user.getSubtitle());
            holder.time_tt.setText(user.getTimestamp());
            holder.description_tt.setText(user.getDescription());

            Picasso.with(getActivity()).load(getResources().getIdentifier(user.getThumbImage(), "drawable", getActivity().getPackageName()))
                    .into(holder.thumb_image);

            Picasso.with(getActivity()).load(getResources().getIdentifier(user.getBigImage(), "drawable", getActivity().getPackageName()))
                    .into(holder.big_image);

            Picasso.with(getActivity()).load(R.drawable.linkedin_bottom)
                    .into(holder.bottom_img);

            return rowView;
        }
    }

    private static boolean canListViewScrollUp(ListView listView) {
        if (android.os.Build.VERSION.SDK_INT >= 14) {
            return ViewCompat.canScrollVertically(listView, -1);
        } else {
            return listView.getChildCount() > 0 &&
                    (listView.getFirstVisiblePosition() > 0
                            || listView.getChildAt(0).getTop() < listView.getPaddingTop());
        }
    }
}
