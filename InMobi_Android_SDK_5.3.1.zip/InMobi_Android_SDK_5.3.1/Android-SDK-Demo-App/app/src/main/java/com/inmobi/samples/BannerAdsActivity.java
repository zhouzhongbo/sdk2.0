package com.inmobi.samples;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.widget.RelativeLayout;

import com.inmobi.ads.InMobiAdRequestStatus;
import com.inmobi.ads.InMobiBanner;
import com.inmobi.samples.nativeads.NewsHeadlinesFragment;

import java.util.Map;

public class BannerAdsActivity extends ActionBarActivity implements
        NewsHeadlinesFragment.OnHeadlineSelectedListener {

    private static final String TAG = BannerAdsActivity.class.getSimpleName(); 
    private static final long YOUR_PLACEMENT_ID = PLACEMENT_ID;

    private InMobiBanner mBannerAd;

    @Override
    public void onArticleSelected(int position) {

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_banner_ads);

        mBannerAd = new InMobiBanner(BannerAdsActivity.this, YOUR_PLACEMENT_ID);
        RelativeLayout fragmentContainer = (RelativeLayout) findViewById(R.id.fragment_container);
        RelativeLayout adContainer = (RelativeLayout) findViewById(R.id.ad_container);
        if (fragmentContainer != null) {
            if (savedInstanceState != null) {
                return;
            }

            mBannerAd.setAnimationType(InMobiBanner.AnimationType.ROTATE_HORIZONTAL_AXIS);
            mBannerAd.setListener(new InMobiBanner.BannerAdListener() {
                @Override
                public void onAdLoadSucceeded(InMobiBanner inMobiBanner) {
                }

                @Override
                public void onAdLoadFailed(InMobiBanner inMobiBanner,
                                           InMobiAdRequestStatus inMobiAdRequestStatus) {
                    Log.w(TAG, "Banner ad failed to load with error: " +
                            inMobiAdRequestStatus.getMessage());
                }

                @Override
                public void onAdDisplayed(InMobiBanner inMobiBanner) {
                }

                @Override
                public void onAdDismissed(InMobiBanner inMobiBanner) {
                }

                @Override
                public void onAdInteraction(InMobiBanner inMobiBanner, Map<Object, Object> map) {
                }

                @Override
                public void onUserLeftApplication(InMobiBanner inMobiBanner) {
                }

                @Override
                public void onAdRewardActionCompleted(InMobiBanner inMobiBanner, Map<Object, Object> map) {
                }
            });

            NewsHeadlinesFragment headlinesFragment = new NewsHeadlinesFragment();
            Bundle args = getIntent().getExtras();
            if (null == args) {
                args = new Bundle();
            }
            args.putBoolean(NewsHeadlinesFragment.ARGS_PLACE_NATIVE_ADS, false);
            headlinesFragment.setArguments(args);
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.fragment_container, headlinesFragment).commit();

            int width = toPixelUnits(320);
            int height= toPixelUnits(50);
            RelativeLayout.LayoutParams bannerLayoutParams =
                    new RelativeLayout.LayoutParams(width, height);
            bannerLayoutParams.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
            bannerLayoutParams.addRule(RelativeLayout.CENTER_HORIZONTAL);
            adContainer.addView(mBannerAd, bannerLayoutParams);
            mBannerAd.load();
        }
    }

    private int toPixelUnits(int dipUnit) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(dipUnit * density);
    }
}
