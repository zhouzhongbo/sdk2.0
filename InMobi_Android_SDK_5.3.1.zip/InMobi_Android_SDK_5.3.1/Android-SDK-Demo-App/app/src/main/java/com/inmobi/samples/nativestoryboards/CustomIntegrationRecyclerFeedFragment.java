package com.inmobi.samples.nativestoryboards;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.inmobi.ads.InMobiAdRequestStatus;
import com.inmobi.ads.InMobiNativeStrand;
import com.inmobi.samples.R;
import com.inmobi.samples.nativestoryboards.FeedData.FeedItem;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Demonstrates the use of InMobiNativeStrand to place ads in a RecyclerView.
 * <p/>
 * Note: Swipe to refresh ads.
 */
public class CustomIntegrationRecyclerFeedFragment extends Fragment {

    private static final String TAG = CustomIntegrationRecyclerFeedFragment.class.getSimpleName();

    //All the InMobiNativeStrand instances created for this list feed will be held here
    private List<InMobiNativeStrand> mStrands = new ArrayList<>();

    private static final int NUM_FEED_ITEMS = 20;
    //Position in feed where the Ads needs to be placed once loaded.
    // Note: Actual position where ad is visible depends on
    // 1. availability of ad (case like NO_FILL)
    // 2. Order in which ad response arrives.
    private int[] mAdPositions = new int[]{2, 5, 8, 13, 18};

    //View type for Content Feed.
    private static final int VIEW_TYPE_CONTENT_FEED = 0;

    //View type for Ad Feed - from InMobi (InMobi Native Strand)
    private static final int VIEW_TYPE_INMOBI_STRAND = 1;

    private RecyclerView mRecyclerView;

    private RecyclerView.Adapter mFeedAdapter;

    private ArrayList<FeedItem> mFeedItems;

    private static final long YOUR_PLACEMENT_ID_HERE = PLACEMENT_ID;

    public static String getTitle() {
        return "RecyclerView Placement";
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.fragment_recycler_feed, container, false);
        mRecyclerView = (RecyclerView) view.findViewById(R.id.recyclerView);
        mRecyclerView.setHasFixedSize(true);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity().getApplicationContext());
        mRecyclerView.setLayoutManager(layoutManager);

        final SwipeRefreshLayout swipeRefreshLayout = SwipeRefreshLayoutWrapper.getInstance(getActivity(),
                new SwipeRefreshLayoutWrapper.Listener() {
                    @Override
                    public boolean canChildScrollUp() {
                        return mRecyclerView.getVisibility() == View.VISIBLE && canViewScrollUp(mRecyclerView);
                    }

                    @Override
                    public void onRefresh() {
                        refreshAds();
                    }
                });
        swipeRefreshLayout.addView(view,
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        return swipeRefreshLayout;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mFeedItems = FeedData.generateFeedItems(NUM_FEED_ITEMS);
        mFeedAdapter = new FeedsAdapter();
        mRecyclerView.setAdapter(mFeedAdapter);
        mFeedAdapter.notifyDataSetChanged();

        for (int position : mAdPositions) {
            final InMobiNativeStrand nativeStrand = new InMobiNativeStrand(getActivity(),
                    YOUR_PLACEMENT_ID_HERE, new StrandAdListener(position));
            mStrands.add(nativeStrand);
        }
        loadAds();
    }

    @Override
    public void onDestroyView() {
        clearAds();
        for (InMobiNativeStrand strand : mStrands) {
            strand.destroy();
        }
        mStrands.clear();
        super.onDestroyView();
    }

    private void loadAds() {
        for (InMobiNativeStrand strand : mStrands) {
            strand.load();
        }
    }

    private void refreshAds() {
        clearAds();
        loadAds();
    }

    private void clearAds() {
        Iterator<FeedItem> feedItemIterator = mFeedItems.iterator();
        while (feedItemIterator.hasNext()) {
            final FeedItem feedItem = feedItemIterator.next();
            if (feedItem instanceof AdFeedItem) {
                feedItemIterator.remove();
            }
        }
        mFeedAdapter.notifyDataSetChanged();
    }

    private static class AdFeedItem extends FeedData.FeedItem {
        InMobiNativeStrand mNativeStrand;

        public AdFeedItem(InMobiNativeStrand nativeStrand) {
            super("", "", "", "", "", "");
            mNativeStrand = nativeStrand;
        }
    }

    private final class StrandAdListener implements InMobiNativeStrand.NativeStrandAdListener {

        private int mPosition;

        public StrandAdListener(int position) {
            mPosition = position;
        }

        @Override
        public void onAdLoadSucceeded(@NonNull InMobiNativeStrand inMobiNativeStrand) {
            Log.d(TAG, "Strand loaded at position " + mPosition);
            if (!mFeedItems.isEmpty()) {
                FeedItem feedItem = mFeedItems.get(mPosition);
                if (feedItem instanceof AdFeedItem) {
                    mFeedItems.remove(mPosition);
                }
                mFeedItems.add(mPosition, new AdFeedItem(inMobiNativeStrand));
                mFeedAdapter.notifyItemInserted(mPosition);
            }
        }

        @Override
        public void onAdLoadFailed(@NonNull InMobiNativeStrand inMobiNativeStrand, @NonNull final InMobiAdRequestStatus inMobiAdRequestStatus) {
            Log.w(TAG, "Ad Load failed (" + inMobiAdRequestStatus.getMessage() + ")");
        }

        @Override
        public void onAdImpressed(@NonNull InMobiNativeStrand inMobiNativeStrand) {
            Log.i(TAG, "Impression recorded for strand at position:" + mPosition);
        }

        @Override
        public void onAdClicked(@NonNull InMobiNativeStrand inMobiNativeStrand) {
            Log.i(TAG, "Click recorded for ad at position:" + mPosition);
        }
    }

    private static boolean canViewScrollUp(RecyclerView recyclerView) {
        if (android.os.Build.VERSION.SDK_INT >= 14) {
            return ViewCompat.canScrollVertically(recyclerView, -1);
        } else {
            return recyclerView.getChildCount() > 0 &&
                    (((LinearLayoutManager) recyclerView.getLayoutManager()).findFirstCompletelyVisibleItemPosition() > 0
                            || recyclerView.getChildAt(0).getTop() < recyclerView.getPaddingTop());
        }
    }

    private static class FeedViewHolder extends RecyclerView.ViewHolder {
        CardView cardView;
        ImageView thumbImage;
        TextView title;
        TextView subTitle;
        TextView timeStamp;
        TextView description;
        ImageView image;
        ImageView bottom;

        FeedViewHolder(View feedCardView) {
            super(feedCardView);
            cardView = (CardView) feedCardView;
            thumbImage = (ImageView) feedCardView.findViewById(R.id.thumb_image);
            title = (TextView) feedCardView.findViewById(R.id.title);
            subTitle = (TextView) feedCardView.findViewById(R.id.subtitle);
            timeStamp = (TextView) feedCardView.findViewById(R.id.time_tt);
            description = (TextView) feedCardView.findViewById(R.id.description_tt);
            image = (ImageView) feedCardView.findViewById(R.id.big_image);
            bottom = (ImageView) feedCardView.findViewById(R.id.bottom_img);

        }
    }

    private static class AdViewHolder extends RecyclerView.ViewHolder {
        CardView cardView;
        View adView;

        AdViewHolder(View adCardView) {
            super(adCardView);
            cardView = (CardView) adCardView;
        }
    }

    public class FeedsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

        @Override
        public int getItemCount() {
            return mFeedItems.size();
        }

        @Override
        public int getItemViewType(int position) {
            final FeedItem feedItem = mFeedItems.get(position);
            if (feedItem instanceof AdFeedItem) {
                return VIEW_TYPE_INMOBI_STRAND;
            }
            return VIEW_TYPE_CONTENT_FEED;
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
            View card = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.recycler_card_layout,
                    viewGroup,
                    false);
            if (viewType == VIEW_TYPE_CONTENT_FEED) {
                LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.listitem,
                        (ViewGroup) card,
                        true);
                return new FeedViewHolder(card);
            } else {
                return new AdViewHolder(card);
            }
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int position) {
            FeedItem feedItem = mFeedItems.get(position);
            if (viewHolder instanceof FeedViewHolder) {
                FeedViewHolder feedViewHolder = (FeedViewHolder) viewHolder;
                feedViewHolder.title.setText(feedItem.getTitle());
                feedViewHolder.subTitle.setText(feedItem.getSubtitle());
                feedViewHolder.timeStamp.setText(feedItem.getTimestamp());
                feedViewHolder.description.setText(feedItem.getDescription());

                Picasso.with(getActivity())
                        .load(getResources().getIdentifier(feedItem.getThumbImage(), "drawable", getActivity().getPackageName()))
                        .into(feedViewHolder.thumbImage);

                Picasso.with(getActivity())
                        .load(getResources().getIdentifier(feedItem.getBigImage(), "drawable", getActivity().getPackageName()))
                        .into(feedViewHolder.image);

                Picasso.with(getActivity())
                        .load(R.drawable.linkedin_bottom)
                        .into(feedViewHolder.bottom);
            } else {
                final AdViewHolder adViewHolder = (AdViewHolder) viewHolder;
                final InMobiNativeStrand nativeStrand = ((AdFeedItem) feedItem).mNativeStrand;
                adViewHolder.cardView.removeAllViews();
                adViewHolder.adView = nativeStrand.getStrandView(adViewHolder.adView, adViewHolder.cardView);
                adViewHolder.cardView.addView(adViewHolder.adView);
            }
        }
    }
}