package com.mopub.custom;

import com.mopub.mobileads.MoPubErrorCode;
import com.mopub.mobileads.MoPubInterstitial;
import com.mopub.mobileads.MoPubInterstitial.InterstitialAdListener;
import com.mopub.mobileads.MoPubView;
import com.mopub.mobileads.MoPubView.BannerAdListener;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class InMobiMopubCustomEventActivity extends Activity implements
		OnClickListener, InterstitialAdListener, BannerAdListener {

	private MoPubView mMopubBannerView;
	private MoPubInterstitial mMopubInterstitialView;
	private Button BtnRefreshAd;
	private Button BtnLoadInterstitial;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		BtnRefreshAd = (Button) findViewById(R.id.btnRefreshAd);
		BtnLoadInterstitial = (Button) findViewById(R.id.btnLoadInterstitial);
		BtnRefreshAd.setOnClickListener(this);
		BtnLoadInterstitial.setOnClickListener(this);
		// Initialize Ad components
		mMopubBannerView = (MoPubView) findViewById(R.id.bannerview);
		mMopubBannerView.setAdUnitId("YOUR_MOPUB_BANNER_UNIT_ID");
		mMopubBannerView.setBannerAdListener(this);
		mMopubBannerView.setAutorefreshEnabled(false);
		mMopubBannerView.loadAd();
	}

	@Override
	public void onDestroy() {
		if (mMopubBannerView != null)
			mMopubBannerView.destroy();
		if (mMopubInterstitialView != null)
			mMopubInterstitialView.destroy();
		super.onDestroy();
	}

	public void getInterstitialAd() {
		mMopubInterstitialView = new MoPubInterstitial(this,
				"YOUR_MOPUB_INTERSTITIAL_UNIT_ID");
		mMopubInterstitialView.setInterstitialAdListener(this);
		mMopubInterstitialView.load();
	}

	public void refreshAd() {
		mMopubBannerView.loadAd();
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		switch (id) {
		case R.id.btnRefreshAd:
			refreshAd();
			break;
		case R.id.btnLoadInterstitial:
			getInterstitialAd();
			break;
		}
	}

	@Override
	public void onInterstitialClicked(MoPubInterstitial arg0) {
		Log.v("Mopub", "Interstitial ad Clicked.");
	}

	@Override
	public void onInterstitialDismissed(MoPubInterstitial arg0) {
		Log.v("Mopub", "Interstitial ad Dismissed.");
	}

	@Override
	public void onInterstitialFailed(MoPubInterstitial arg0, MoPubErrorCode arg1) {
		Log.v("Mopub",
				"Interstitial ad failed with ErrorCode " + arg1.toString());
	}

	@Override
	public void onInterstitialLoaded(MoPubInterstitial arg0) {
		Log.v("Mopub", "Interstitial ad loaded successfully.");
		if (mMopubInterstitialView.isReady()) {
			mMopubInterstitialView.show();
		}
	}

	@Override
	public void onInterstitialShown(MoPubInterstitial arg0) {
		Log.v("Mopub", "Interstitial ad Shown");
	}

	@Override
	public void onBannerClicked(MoPubView arg0) {
		Log.v("Mopub", "Banner ad Clicked");
	}

	@Override
	public void onBannerCollapsed(MoPubView arg0) {
		Log.v("Mopub", "Banner ad Collapsed");
	}

	@Override
	public void onBannerExpanded(MoPubView arg0) {
		Log.v("Mopub", "Banner ad Expanded");
	}

	@Override
	public void onBannerFailed(MoPubView arg0, MoPubErrorCode arg1) {
		Log.v("Mopub",
				"Banner ad failed to load with ErrorCode" + arg1.toString());
	}

	@Override
	public void onBannerLoaded(MoPubView arg0) {
		Log.v("Mopub", "Banner ad loaded successfully.");
	}
}
